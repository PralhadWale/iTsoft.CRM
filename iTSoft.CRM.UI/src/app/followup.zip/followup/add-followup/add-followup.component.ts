import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-followup',
  templateUrl: './add-followup.component.html',
  styleUrls: ['./add-followup.component.scss']
})
export class AddFollowupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
