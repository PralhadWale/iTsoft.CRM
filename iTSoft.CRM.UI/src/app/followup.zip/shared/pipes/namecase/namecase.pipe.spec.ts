import { NamecasePipe } from './namecase.pipe';

describe('NamecasePipe', () => {
  it('create an instance', () => {
    const pipe = new NamecasePipe();
    expect(pipe).toBeTruthy();
  });
});
